#!/bin/bash

dialog --yesno "Вы хотите продолжить?" 5 50
response1=$?

if [ $response1 -eq 0 ]; then
    dialog --yesno "Вы уверены, что хотите продолжить?" 5 50
    response2=$?

    if [ $response2 -eq 0 ]; then
        dialog --msgbox "Вы выбрали продолжить." 5 50
    else
        dialog --msgbox "Вы выбрали не продолжать." 5 50
    fi
else
    dialog --msgbox "Вы выбрали не продолжать." 5 50
fi
