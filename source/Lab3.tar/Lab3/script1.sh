#!/bin/bash

name=$(dialog --inputbox "Введите ваше имя:" 8 40 3>&1 1>&2 2>&3 3>&-)

if [ -z "$name" ]; then
    dialog --msgbox "Вы не ввели имя. Скрипт завершен." 7 40
    exit 1
fi

profession=$(dialog --inputbox "Введите вашу профессию:" 8 40 3>&1 1>&2 2>&3 3>&-)

if [ -z "$profession" ]; then
    dialog --msgbox "Вы не ввели профессию. Скрипт завершен." 7 40
    exit 1
fi

dialog --msgbox "Ваше имя: $name\nВаша профессия: $profession" 7 40
