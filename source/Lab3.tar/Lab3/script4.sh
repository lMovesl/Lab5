#!/bin/bash

while true; do

choice=$(dialog --menu "Выберите валюту для получения котировки:" 14 40 5 \
						1 "USD" \
						2 "EUR" \
						3 "PLN" \
						4 "RUB" \
						5 "exit" 3>&1 1>&2 2>&3) 	

if [ -z "$choice" ]; then
	dialog --msgbox "Вы не выбрали валюту." 5 50
	continue
fi

case $choice in
	"1") rate="3,2891"; currency="USD";;
	"2") rate="3,5672"; currency="EUR";;
	"3") rate="0,8264"; currency="PLN";;
	"4") rate="0,0342"; currency="RUB";;
	"5") dialog --clear; exit 0;;
esac

dialog --msgbox "$currency = $rate BYN" 5 50

done
