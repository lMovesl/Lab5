#!/bin/bash

echo "Выберите валюту для получения котировки:"
echo "1.USD"
echo "2.EUR"
echo "3.PLN"
echo "4.RUB" 	

read -p "Введдите валюту для получения котировки: " currency

case $currency in
	"USD") rate="3,2891";;
	"EUR") rate="3,5672";;
	"PLN") rate="0,8264";;
	"RUB") rate="0,0342";;
	*) "неверно введена валюта"; exit 1;;
esac

echo "$currency = $rate BYN"

