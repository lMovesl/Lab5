#!/bin/bash

while true; do
currency=$(dialog --inputbox "Выберите валюту для получения котировки:
						\n1.USD
						\n2.EUR
						\n3.PLN
						\n4.RUB 
						\n5.exit" 14 40 3>&1 1>&2 2>&3 3>&-) 	

if [ -z "$currency" ]; then
	dialog --msgbox "Вы не выбрали валюту." 5 50
	continue
fi

case $currency in
	"USD") rate="3,2891";;
	"EUR") rate="3,5672";;
	"PLN") rate="0,8264";;
	"RUB") rate="0,0342";;
	"exit") dialog --clear; exit 0;;
	*) dialog --msgbox "неверно введена валюта" 5 50; continue;;
esac

dialog --msgbox "$currency = $rate BYN" 5 50

done
